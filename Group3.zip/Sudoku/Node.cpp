//
// Created by ahmad-obeid on 10/14/19.
//

#include "Node.h"
Node::Node() {
    next= nullptr;
    prev=  nullptr;
    row= 0;
    col= 0;
    options="";
    num='0';
}