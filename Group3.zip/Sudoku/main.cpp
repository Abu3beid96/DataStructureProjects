#include <iostream>
#include <fstream>
#include "SudokuTree.h"
//GROUP 3:
// Ahmad Obeid 11820869
// Roaa Arabasi 11820448
// Wisam Bsharat 11819201
int main() {
   SudokuTree s("SudokuGrid.txt");
   s.solve();


    return 0;
}